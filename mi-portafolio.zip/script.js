// Aquí puedes añadir funciones JS más adelante.
// Ejemplo: un botón que muestre un mensaje en consola
console.log("Tu portafolio está cargado correctamente 🚀");